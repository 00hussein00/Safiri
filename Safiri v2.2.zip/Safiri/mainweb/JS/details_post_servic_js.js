function getServic(){
    console.log("click");
    window.location.href = "get_service_html.html";
}